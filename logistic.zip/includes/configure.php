<?php
define( "BASE_URL", "/logistic/");
define("ROOT_PATH", $_SERVER["DOCUMENT_ROOT"] . "/logistic/");
define("PAGINATION", 3);