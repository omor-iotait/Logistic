<?php
require_once("includes/configure.php");
include(ROOT_PATH . "includes/db.php");
include(ROOT_PATH . "classes/Session.php");
header('Location: '.BASE_URL.'customer/index.php');
?>