<footer class="main-footer">
    <strong>Copyright &copy; 2019-2020 <a href="#">Amber Logistic</a>.</strong>
    All rights reserved.
</footer>